#define UTMPX
#include "tst-utmp.c"
