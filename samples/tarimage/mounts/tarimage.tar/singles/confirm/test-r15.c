#include <stdio.h>

long long base_addr(){
  asm("movq %r15, %rax");
}

int zmain(int argc, char* argv[]) {
  printf("Hello, World! %llX", base_addr());
  return 0;
}
