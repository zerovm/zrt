#define CHAR wchar_t
#define L(str) L##str
#define SSCANF swscanf
#include <wchar.h>
#include "tst-sscanf.c"
