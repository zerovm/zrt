find -name "*.nexe"| xargs rm -f
find -name "*.std"| xargs rm -f
find -name "*.log"| xargs rm -f
find -name "*.o"| xargs rm -f
find -name "*.manifest"| xargs rm -f
