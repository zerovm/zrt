/* Some machines have these macros defined in elf/tst-auditmod1.c directly.
   New machines can supply a tst-audit.h to define these macros used there.


# define pltenter la_CPU_gnu_pltenter
# define pltexit la_CPU_gnu_pltexit
# define La_regs La_CPU_regs
# define La_retval La_CPU_retval
# define int_retval lrv_RETVALREG

*/
